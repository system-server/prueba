<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('records', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('age');
            $table->string('email')->unique();
            $table->string('phone');
            $table->string('study');
            $table->string('you_reside');
            $table->enum('sexual_gender', ['Hombre', 'Mujer']);
            $table->enum('taller', ['Sexualidad','Una-fe-viva','Conociendo-la-historia-de-la-Biblia','Cosmovision-cristiana','Método-manuscrito-de-E.B.','Evangelismo-creativo','Disciplinas-espirituales','Quién-es-Jesús-y-que-significa-seguirlo','Fe-y-profesión']);
            $table->enum('bible_study', ['yes', 'No']);
            $table->enum('participation',['lider', 'asistente', 'no_asiste']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('records');
    }
}
