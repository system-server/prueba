$(document).ready(function() {
    $('.contactForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            name: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese su nombre'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese su correo electrónico'
                    },
                    emailAddress: {
                        message: 'Correo electrónico no valido'
                    }
                }
            },
            taller: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese taller'
                    }
                }
            },
            sexual_gender: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese su genero'
                    }
                }
            },
            you_reside: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese su residencia'
                    }
                }
            },
            age: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese su edad'
                    }
                }
            },

            phone: {
                validators: {
                    notEmpty: {
                        message: 'Ingrese su telefono'
                    }
                }
            }
        }
    });
});