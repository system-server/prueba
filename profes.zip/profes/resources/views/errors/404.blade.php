@extends('panel.template.main')
@section('title', 'Error 404')

@section('content')
    <div class="container text-center">
        <h1 class="text-danger">La página no se ha encontrado.</h1>
        <div class="col-md-4"></div>
        <div class="col-md-4">

        </div>
    </div>
    <br>
@endsection
