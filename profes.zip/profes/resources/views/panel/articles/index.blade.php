@extends('panel.template.main')
@section('title', 'Articulos')

@section('content')
    <div class="page-title">
        <div class="title_left">
            <h3>Lista de Articulos</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="fa fa-th-list"></i> Articulos registradas {{ App\Article::all()->count() }} </h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                    <table class="table table-striped projects table-bordered table-hover">
                        <thead>
                        <tr>
                            <th >ID</th>
                            <th>Nombre</th>
                            <th>Categoría</th>
                            <th>Usuario</th>
                            <th>Estado</th>
                            <th class="text-center">Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach($articles as $article)
                            <tr>
                                <td>{{ $article->id }}</td>
                                <td>{{ $article->title }}</td>
                                <td>{{ $article->category->name }}</td>
                                <td>{{ $article->get_nameUser() }}</td>
                                <td>
                                    @if($article->active == 1)
                                        <span class="text-success">Activo</span>
                                    @else
                                        <span class="text-danger">Inactivo</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if(Auth::user()->admin())
                                    <a href="{{ route('panel.articles.edit', $article->id) }}" class="btn btn-info btn-xs" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                                    <a href="{{ route('panel.articles.destroy', $article->id) }}"  onclick="return confirm('¿Seguro que deseas eliminarlo?')" class="btn btn-danger btn-xs" data-toggle="tooltip" title="Eliminar"><i class="fa fa-trash-o"></i></a>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <!-- end project list -->
                     <div class="text-center">
                        {!! $articles->render() !!}
                     </div>

                </div>
            </div>
        </div>
    </div>

@endsection