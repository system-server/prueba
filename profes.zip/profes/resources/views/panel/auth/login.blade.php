@extends('panel.template.login')

@section('title', 'Acceder')

@section('content')
    <section class="login_content">

        {!! Form::open(['route' => 'panel.auth.login', 'method' => 'POST']) !!}
            <h1>Login</h1>
            <div>
                @include('flash::message')
                @include('panel.template.partials.alerts.errors')
            </div>
            <div>
                {!! Form::label('email', 'Correo Electronico:') !!}
                {!! Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'example@gmail.com']) !!}
            </div>
            <div>
                {!! Form::label('password', 'Contraseña:') !!}
                {!! Form::password('password', ['class' => 'form-control', 'placeholder' => '*********']) !!}
            </div>
            <div>
                {!! Form::submit('Acceder', ['class' => 'btn btn-info pull-right']) !!}
            </div>
            <div class="clearfix"></div>
            <div class="separator">
                <div>
                    <h1><i class="fa fa-paw" style="font-size: 26px;"></i> Luisilloss!</h1>

                    <p>©2016 Todos los derechos reservados.  </p>
                    <p>Compañerismo Esrudiantil, Puebla</p>
                </div>
            </div>
        {!! Form::close() !!}
        <!-- form -->
    </section>
@endsection