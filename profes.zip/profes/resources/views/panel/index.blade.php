@extends('panel.template.main')
@section('title', 'Dashboard')

@section('content')
    <div class="page-title">
        <div class="title_left">
            <h3>Dashboard</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <!-- top tiles -->
    
    <div class="row tile_count">

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">

                <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
                <div class="count"> {{ App\User::all()->count() }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Contacts</span>
                <div class="count"> {{ App\Registry::all()->count() }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/1"><span class="count_top"></i>Sexualidad</span></a>
                <div class="count green">{{ $taller1 }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <a href="panel/list/2"><span class="count_top"></i>Una fe viva</span></a>
                <div class="count">{{ $taller2 }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/3"><span class="count_top"></i>Conociendo la historia</span></a>
                <div class="count">{{ $taller3 }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/4"><span class="count_top"></i>Cosmovision cristiana</span></a>
                <div class="count">{{ $taller4 }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/5"> <span class="count_top"></i>Método manuscrito</span></a>    
                <div class="count green">{{ $taller5 }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/6"><span class="count_top"></i>Evangelismo creativo</span></a>
               <div class="count green">{{ $taller6 }}</div>
            </div>
         </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
                <div class="right">
                <a href="panel/list/7"> <span class="count_top"></i>Disciplinas espirituales</span></a>    
                <div class="count green">{{ $taller7 }}</div>
            </div>
       </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
             <div class="left"></div>
             <div class="right">
             <a href="panel/list/8"> <span class="count_top"></i>Quién es Jesús</span></a>
               <div class="count green">{{ $taller8 }}</div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
             <div class="left"></div>
             <div class="right">
             <a href="panel/list/9"> <span class="count_top"></i>Fe y profesión</span></a>    
                  <div class="count green">{{ $taller9 }}</div>
            </div>
        </div>
        
  </div>
    <!-- /top tiles -->
@endsection