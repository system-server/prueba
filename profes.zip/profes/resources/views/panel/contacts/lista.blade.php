@extends('panel.template.main')
@section('title', 'Contactos')

@section('content')
    <div class="page-title">
        <div class="title_left">
            <h3>Lista de contactos  </h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="glyphicon glyphicon-user"></i> Contactos registrados {{ $count}}</h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="excel2/{{$id}}">Exportar Excel</a>
                                </li>
                                <li><a href="#">Exportar PDF</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                    <table class="table table-striped projects table-bordered table-hover">
                        <thead>
                        <tr>
                            <th style="width: 1%">ID</th>
                            <th style="width: 20%">Nombre</th>
                            <th>Email</th>
                            <th>Taller</th>
                            <th >Genero</th>
                            <th>Fecha de registro</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($lists as $list)
                            <tr>
                                <td>{{ $list->id }}</td>
                                <td>{{ $list->name }}</td>
                                <td>{{ $list->email }}</td>
                                <td> {{ $list->taller }}</td>
                                <td> {{ $list->sexual_gender }}</td>
                                <td> {{ $list->created_at }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <!-- end project list -->

                   
                </div>
            </div>
        </div>
    </div>

@endsection