@extends('panel.template.main')
@section('title', 'Perfil de usuario')

@section('content')

    <div class="page-title">
        <div class="title_left">
            <h3>Usuarios</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="glyphicon glyphicon-user"></i> Usuario  {{ $user->name  }}</h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                    <div class="row">
                        <div class="col-md-4">
                            <img src="/upload/{{ $user->path }}" alt="..." class="img-thumbnail " style="height: 200px; width: 250px">
                        </div>
                        <div class="col-md-4">
                            <p><strong>Nombre:</strong> {{ $user->name }} </p>
                            <p><strong>Correo:</strong> {{ $user->email }} </p>
                            <p><strong>Tipo:</strong> {{ $user->type }} </p>
                        </div>
                    </div>



                    <p>
                        <a href="{{ route('panel.users.index')  }}" class="btn btn-default btn-success">Volver</a>
                    </p>
                    <!-- end project list -->

                </div>
            </div>
        </div>
    </div>


@endsection

@section('js')

@endsection