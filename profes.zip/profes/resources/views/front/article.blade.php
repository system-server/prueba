@extends('front.template.main_two')

@section('title', $article->title )

@section('content')


 

    <h1 class="text-center">Taller</h1>
    <div class="row">
            <div class="col-lg-12">
                <ol class="breadcrumb">
                    <li><a href="{{ route('front.index') }}">Home</a>
                    </li>
                    <li><a href="{{ route('front.list') }}">Talleres</a>
                    </li>
                    <li class="active">{{ $article->title }}</li>
                </ol>
            </div>
 </div>
    <h2 class="title-front left">{{ $article->title }}</h2>
    <h4><strong>Tallerista:</strong> {{$article->autor}}</h4>
    <hr>
    
    <div class="row">
    
        <div class="col-md-4 text-center">
        @foreach($article->images as $image)
        <img src="{{ asset('upload/articles/' . $image->name) }}" class="img-responsive img-circle text-center" alt="Compa" style="height:350px; width: 300px;">
         @endforeach
    </div>
    <br>
    
        <div class="col-md-8">
    
            <h4>{!! $article->content !!}</h4>
            <h3>Comentarios:</h3>
            <hr>
            <div id="disqus_thread"></div>
            <script>
                /**
                 * RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
                 * LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables
                 */
                /*
                 var disqus_config = function () {
                 this.page.url = PAGE_URL; // Replace PAGE_URL with your page's canonical URL variable
                 this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
                 };
                 */
                (function() { // DON'T EDIT BELOW THIS LINE
                    var d = document, s = d.createElement('script');

                    s.src = '//campamento-estudiantil.disqus.com/embed.js';

                    s.setAttribute('data-timestamp', +new Date());
                    (d.head || d.body).appendChild(s);
                })();
            </script>
            <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
        </div>
    </div>
  <!-- /.row -->
    @endsection
    @section('js')

    <script src="{{ asset('/plugins/theme/js/jquery.gmap3.min.js') }}"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script id="dsq-count-scr" src="//campamento-estudiantil.disqus.com/count.js" async></script>
    <script>
        jQuery(function($){
            $('#map_canvas').gmap3({
                marker:{
                    address: '19.3598357,-98.1524267'

                },
                map:{
                    options:{
                        zoom: 15,
                        scrollwheel: true,
                        streetViewControl : true
                    }
                }
            });
        });
    </script>
@endsection