@extends('front.template.main')

@section('title', 'Registrado')

@section('content')

    <div class="row">
        <h1 class="center-align">Gracias por registrarte</h1>
        <h5 class="center-align">En breve nos comunicaremos contigo</h5>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>

@endsection