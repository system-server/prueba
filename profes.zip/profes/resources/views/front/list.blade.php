@extends('front.template.main_two')

@section('title', 'Talleres')

@section('content')
 
 <h2 class="title-front left">{{ trans('app.title_last_article') }}</h2>
 <div class="row">
            <div class="col-lg-12">
                <ol class="breadcrumb">
                    <li><a href="{{ route('front.index') }}">Home</a>
                    </li>
                    <li class="active">Talleres</li>
                </ol>
            </div>
 </div>
    <div class="row">
    <!-- Page Heading/Breadcrumbs -->
       
        <div class="col-md-12">
            <div class="row">
                @foreach($articles as $article)
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <a href="{{ route('front.view.article', $article->slug) }}" class="thumbnail " >
                                @foreach($article->images as $image)
                                <img class="img-responsive" src="{{ asset('upload/articles/' . $image->name) }}" alt="..." style="height:250px; width: 300px;">
                                @endforeach
                            </a>
                            <a href="{{ route('front.view.article', $article->slug) }}">
                                <h4 class="text-center">{{ $article->title }}</h4>
                            </a>
                            <hr>
                            <i class="fa fa-folder-open-o"><a href="{{ route('front.search.category', $article->category->name)}}"> {{ $article->category->name }}</a></i>
                            <div class="pull-right">
                                <i class="fa fa-clock-o"></i> {{ $article->created_at->diffForHumans() }}
                            </div>
                        </div>
                    </div>
                   <hr>
                </div>
                @endforeach
            </div>
           <div class="text-center">
               {!! $articles->render() !!}
           </div>
        </div>
    </div>

 <!-- /.row -->
    @endsection
    @section('js')

    <script src="{{ asset('/plugins/theme/js/jquery.gmap3.min.js') }}"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script>
        jQuery(function($){
            $('#map_canvas').gmap3({
                marker:{
                    address: '19.3598357,-98.1524267'

                },
                map:{
                    options:{
                        zoom: 15,
                        scrollwheel: true,
                        streetViewControl : true
                    }
                }
            });
        });
    </script>
@endsection