
<div class="alert alert-danger alert-dismissible" role="alert">
    <p><strong>Aviso:</strong> Si no haz hecho tu deposito no puedes registrarte.</p>
</div>
