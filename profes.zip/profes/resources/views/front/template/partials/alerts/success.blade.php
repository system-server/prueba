
    <div class="alert alert-warning alert-dismissible" role="alert">
         <p>Cualquier duda, te puedes comunicar con nosotros por telefono o correo electrónico.</p>
    </div>
