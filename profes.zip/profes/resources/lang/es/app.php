<?php

return [
    'title_last_article' => 'Talleres',
    'title_categories' => 'Categorías'
];