<?php

return [
    'title_last_article' => 'Whorshop',
    'title_categories' => 'Categories'
];