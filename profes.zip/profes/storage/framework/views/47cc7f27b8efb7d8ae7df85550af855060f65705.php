<?php $__env->startSection('title', $article->title ); ?>

<?php $__env->startSection('content'); ?>


 

    <h1 class="text-center">Taller</h1>
    <div class="row">
            <div class="col-lg-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('front.index')); ?>">Home</a>
                    </li>
                    <li><a href="<?php echo e(route('front.list')); ?>">Talleres</a>
                    </li>
                    <li class="active"><?php echo e($article->title); ?></li>
                </ol>
            </div>
 </div>
    <h2 class="title-front left"><?php echo e($article->title); ?></h2>
    <h4><strong>Tallerista:</strong> <?php echo e($article->autor); ?></h4>
    <hr>
    
    <div class="row">
    
        <div class="col-md-4 text-center">
        <?php foreach($article->images as $image): ?>
        <img src="<?php echo e(asset('upload/articles/' . $image->name)); ?>" class="img-responsive img-circle text-center" alt="Compa" style="height:350px; width: 300px;">
         <?php endforeach; ?>
    </div>
    <br>
    
        <div class="col-md-8">
    
            <h4><?php echo $article->content; ?></h4>
            <h3>Comentarios:</h3>
            <hr>
            <div id="disqus_thread"></div>
            <script>
                /**
                 * RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
                 * LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables
                 */
                /*
                 var disqus_config = function () {
                 this.page.url = PAGE_URL; // Replace PAGE_URL with your page's canonical URL variable
                 this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
                 };
                 */
                (function() { // DON'T EDIT BELOW THIS LINE
                    var d = document, s = d.createElement('script');

                    s.src = '//campamento-estudiantil.disqus.com/embed.js';

                    s.setAttribute('data-timestamp', +new Date());
                    (d.head || d.body).appendChild(s);
                })();
            </script>
            <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
        </div>
    </div>
  <!-- /.row -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('/plugins/theme/js/jquery.gmap3.min.js')); ?>"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script id="dsq-count-scr" src="//campamento-estudiantil.disqus.com/count.js" async></script>
    <script>
        jQuery(function($){
            $('#map_canvas').gmap3({
                marker:{
                    address: '19.3598357,-98.1524267'

                },
                map:{
                    options:{
                        zoom: 15,
                        scrollwheel: true,
                        streetViewControl : true
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.main_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>