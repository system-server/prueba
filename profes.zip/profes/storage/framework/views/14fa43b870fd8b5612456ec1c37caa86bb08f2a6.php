<?php $__env->startSection('title', 'Acceso Negado'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-title">
        <div class="title_left">
            <h3>NO Autorizado</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="glyphicon glyphicon-user"></i> Usuario no Autorizado </h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>

                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->

                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-warning">
                            <div class="panel-heading">
                                <div class="panel-title">Acceso Restringido</div>
                            </div>
                            <div class="panel-body">
                                <img class="img-responsive center-block" src="<?php echo e(asset('img/error_access.png')); ?>">
                                <hr>
                                <strong class="text-center">
                                    <p class="text-center">Usted no tiene acceso a esta zona</p>
                                </strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>