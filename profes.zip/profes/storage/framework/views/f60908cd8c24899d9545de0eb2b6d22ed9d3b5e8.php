<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Lista de usuarios</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="glyphicon glyphicon-user"></i> Usuarios registrados <?php echo e(\App\User::all()->count()); ?></h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                    <table class="table table-striped projects table-bordered table-hover">
                        <thead>
                        <tr>
                            <th style="width: 1%">ID</th>
                            <th style="width: 20%">Nombre</th>
                            <th>Email</th>
                            <th>Tipo</th>
                            <th class="text-center">Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->type == 'admin'): ?>
                                    <span class="label label-danger"><?php echo e($user->type); ?></span>
                                <?php else: ?>
                                    <span class="label label-primary"><?php echo e($user->type); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('panel.users.show', $user->id)); ?>" class="btn btn-primary btn-xs" data-toggle="tooltip" title="Perfil"><i class="fa fa-folder"></i></a>
                                <a href="<?php echo e(route('panel.users.edit', $user->id)); ?>" class="btn btn-info btn-xs" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                                <a href="<?php echo e(route('panel.users.destroy', $user->id)); ?>"  onclick="return confirm('¿Seguro que deseas eliminarlo?')" class="btn btn-danger btn-xs" data-toggle="tooltip" title="Eliminar"><i class="fa fa-trash-o"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <!-- end project list -->
                    <div class="text-center">
                        <?php echo $users->render(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>