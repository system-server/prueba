<?php $__env->startSection('title', 'Categorias'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Lista de Categorías</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="fa fa-tag"></i> Categorías registradas <?php echo e(App\Category::all()->count()); ?></h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                    <table class="table table-striped projects table-bordered table-hover">
                        <thead>
                        <tr>
                            <th >ID</th>
                            <th>Nombre</th>
                            <th>Estado</th>
                            <th class="text-center">Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($categories as $category): ?>
                            <tr>
                                <td><?php echo e($category->id); ?></td>
                                <td><?php echo e($category->name); ?></td>
                                <td>
                                    <?php if($category->active == 1): ?>
                                        <span class="text-success">Activo</span>
                                    <?php else: ?>
                                        <span class="text-danger">Inactivo</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if(Auth::user()->admin()): ?>
                                    <a href="<?php echo e(route('panel.categories.edit', $category->id)); ?>" class="btn btn-info btn-xs" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil"></i></a>
                                    <a href="<?php echo e(route('panel.categories.destroy', $category->id)); ?>"  onclick="return confirm('¿Seguro que deseas eliminarlo?')" class="btn btn-danger btn-xs" data-toggle="tooltip" title="Eliminar"><i class="fa fa-trash-o"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <!-- end project list -->

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>