<?php $__env->startSection('title', 'Acceder'); ?>

<?php $__env->startSection('content'); ?>
    <section class="login_content">

        <?php echo Form::open(['route' => 'panel.auth.login', 'method' => 'POST']); ?>

            <h1>Login</h1>
            <div>
                <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('panel.template.partials.alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div>
                <?php echo Form::label('email', 'Correo Electronico:'); ?>

                <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'example@gmail.com']); ?>

            </div>
            <div>
                <?php echo Form::label('password', 'Contraseña:'); ?>

                <?php echo Form::password('password', ['class' => 'form-control', 'placeholder' => '*********']); ?>

            </div>
            <div>
                <?php echo Form::submit('Acceder', ['class' => 'btn btn-info pull-right']); ?>

            </div>
            <div class="clearfix"></div>
            <div class="separator">
                <div>
                    <h1><i class="fa fa-paw" style="font-size: 26px;"></i> Luisilloss!</h1>

                    <p>©2016 Todos los derechos reservados.  </p>
                    <p>Compañerismo Esrudiantil, Puebla</p>
                </div>
            </div>
        <?php echo Form::close(); ?>

        <!-- form -->
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>