<?php $__env->startSection('title', 'Registro'); ?>

<?php $__env->startSection('content'); ?>
   <div class="row">
      <h2 class="center">Registro Campamento</h2>
      <div class="col s12">
         <?php echo Form::open(['route' => 'contact.store', 'method' => 'POST']); ?>

         <div class="row">
            <div class="input-field col s2"></div>
            <div class="input-field col s4">
               <input placeholder="Juan" id="name" name="name" type="text" class="validate">
               <label for="name">Nombre</label>
            </div>
            <div class="input-field col s4">
               <input placeholder="example@gmail.com" name="email" id="email" type="email" class="validate">
               <label for="email">Email</label>
            </div>
         </div>
         <div class="row">
            <div class="input-field col s2"></div>
            <div class="input-field col s4">
               <input placeholder="25" id="age" name="age" type="text" class="validate">
               <label for="age">Edad</label>
            </div>
            <div class="input-field col s4">
               <input placeholder="Ingeniería" id="profession" name="profession" type="text" class="validate">
               <label for="profession">Profesión</label>
            </div>
         </div>
         <div class="row">
            <div class="input-field col s2"></div>
            <div class="input-field col s4">
                  <?php echo Form::select('civil_state', ['married' => 'Casado', 'single' => 'Soltero'],
               null, ['placeholder' => 'Seleccione una opción... ']); ?>

               <label>Estado civil</label>
            </div>
            <div class="input-field col s4">
               <?php echo Form::select('sexual_gender', ['Hombre' => 'Hombre', 'Mujer' => 'Mujer'],
              null, [ 'placeholder' => 'Seleccione una opción... ']); ?>

               <label>Genero Sexual</label>
            </div>
         </div>
         <div class="row">
            <div class="input-field col s2"></div>
            <div class="input-field col s4">
               <input placeholder="Puebla" id="you_reside" name="you_reside" type="text" class="validate">
               <label for="you_reside">Donde radicas:</label>
            </div>
            <div class="input-field col s4">
               <input placeholder="2221232425" id="phone" name="phone" type="text" class="validate">
               <label for="phone">Telefono:</label>
            </div>
         </div>
         <div class="row">
            <div class="input-field col s2"></div>
            <div class="input-field col s4">
               <?php echo Form::select('bible_study', ['yes' => 'SI', 'No' => 'NO'],
               null, ['placeholder' => 'Seleccione una opción... ']); ?>

               <label>Asistes a un estudio bíblico</label>
            </div>
            <div class="input-field col s4">
               <?php echo Form::select('participation', ['lider' => 'Lider', 'asistente' => 'Asistente', 'miembro' => 'miembro'],
               null, ['placeholder' => 'Seleccione una opción... ']); ?>

               <label>Participación en el estudio bíblico</label>
            </div>
         </div>
         <div class="row">
            <div class="input-field col s2"></div>
            <div class="input-field col s4">
               <input placeholder="Bancomer" id="bank_dep" name="bank_dep" type="text" class="validate">
               <label for="bank_dep">Banco de Deposito</label>
            </div>
            <div class="input-field col s4">
               <input placeholder="56478953154" id="trans_num" name="trans_num" type="text" class="validate">
               <label for="trans_num">Numero de transferencia(OXXO)</label>
            </div>
         </div>
         <div class="row">
            <div class="input-field col s8"></div>
            <button class="btn waves-effect  waves-light #ffc400" type="submit">Registrar
               <i class="material-icons right">send</i>
            </button>
         </div>
         <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
         <?php echo Form::close(); ?>

      </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>