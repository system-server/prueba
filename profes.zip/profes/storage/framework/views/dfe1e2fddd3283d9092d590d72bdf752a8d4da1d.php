<?php $__env->startSection('title', 'Contact' ); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Contactos</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="glyphicon glyphicon-user"></i> Contacto  <?php echo e($contact->name); ?></h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Settings 1</a>
                                </li>
                                <li><a href="#">Settings 2</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                   <div class="row">
                       <div class="col-md-4">
                           <p><strong>Nombre:</strong> <?php echo e($contact->name); ?> </p>
                           <p><strong>Correo:</strong> <?php echo e($contact->email); ?> </p>
                           <p><strong>Edad:</strong> <?php echo e($contact->age); ?> </p>
                           <p><strong>Telefono:</strong> <?php echo e($contact->phone); ?> </p>
                           <p><strong>Profesión:</strong> <?php echo e($contact->profession); ?> </p>
                           <p><strong>Genero sexual:</strong> <?php echo e($contact->sexual_gender); ?> </p>
                           <p><strong>Estado civil:</strong> <?php echo e($contact->civil_state); ?> </p>
                       </div>
                       <div class="col-md-4">
                           <p><strong>Radica en:</strong> <?php echo e($contact->you_reside); ?> </p>
                           <p><strong>Ocupacíon:</strong> <?php echo e($contact->you_spend); ?> </p>
                           <p><strong>Participa en el estudio:</strong> <?php echo e($contact->participation); ?> </p>
                           <p><strong>Banco de Deposito:</strong> <?php echo e($contact->bank_dep); ?> </p>
                           <p><strong>Numero de Transacción:</strong> <?php echo e($contact->trans_num); ?> </p>
                           <p><strong>Fecha de registro:</strong> <?php echo e($contact->created_at); ?> </p>
                       </div>
                   </div>



                    <p>
                        <a href="<?php echo e(route('panel.contacts.index')); ?>" class="btn btn-default btn-success">Volver</a>
                    </p>
                    <!-- end project list -->

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>