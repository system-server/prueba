<?php $__env->startSection('title', 'Agregar usuario'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Categorías</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="x_panel">
            <div class="x_title">
                <h2>Agregar categoría <small>Formulario</small></h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="#">Settings 1</a>
                            </li>
                            <li><a href="#">Settings 2</a>
                            </li>
                        </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <br />

                <?php echo Form::open(['route' => 'panel.categories.store', 'method' => 'POST', 'id' => 'demo-form2', 'class' => 'form-horizontal form-label-left', 'files' => true, 'data-parsley-validate']); ?>

                <div class="form-group">
                    <div class="col-md-3 col-sm-3 col-xs-12"></div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <?php echo $__env->make('panel.template.partials.alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('name','Nombre *', array('class' => 'control-label col-md-3 col-sm-3 col-xs-12', 'for' => 'name') ); ?>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <?php echo Form::text('name', null,['class' => 'form-control col-md-7 col-xs-12', 'id' => 'name', 'placeholder' => 'Estudio']); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo Form::label('active','Publicar la categoría despues de cargar. *', array('class' => 'control-label col-md-3 col-sm-3 col-xs-12', 'for' => 'actvie') ); ?>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <?php echo Form::checkbox('active', 'true', '1', ['class' => ' col-md-7 col-xs-12 flat']); ?>

                    </div>
                </div>
                <div class="ln_solid"></div>
                <div class="form-group">
                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3 pull-right">
                        <a href="<?php echo e(route('panel.categories.index')); ?>" class="btn btn-primary">Cancelar</a>
                        <?php echo Form::submit('Registrar', ['class' => 'btn btn-success']); ?>

                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>