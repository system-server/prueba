<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $__env->yieldContent('title', 'Default'); ?> | Campamento </title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('plugins/theme/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/theme/css/style.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('plugins/theme/css/modern-business.css')); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('plugins/theme/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

    <link rel='stylesheet' id='imic_fullcalendar_css-css'  href='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/fullcalendar/fullcalendar.css' type='text/css' media='all' />
    <link rel='stylesheet' id='imic_fullcalendar_print-css'  href='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/fullcalendar/fullcalendar.print.css' type='text/css' media='all' />
    <link rel='stylesheet' id='imic_mediaelementplayer-css'  href='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/mediaelement/mediaelementplayer.css' type='text/css' media='all' />
    <link rel="icon" href="http://compa.org.mx/wp-content/uploads/2015/01/cropped-Compa-logo-32x32.png" sizes="32x32">
    <link rel="icon" href="http://compa.org.mx/wp-content/uploads/2015/01/cropped-Compa-logo-192x192.png" sizes="192x192">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style type="text/css">
        .text-primary, .btn-primary .badge, .btn-link,a.list-group-item.active > .badge,.nav-pills > .active > a > .badge, p.drop-caps:first-child:first-letter, .accent-color, .events-listing .event-detail h4 a, .featured-sermon h4 a, .page-header h1, .post-more, ul.nav-list-primary > li a:hover, .widget_recent_comments a, .navigation .megamenu-container .megamenu-sub-title, .woocommerce div.product span.price, .woocommerce div.product p.price, .woocommerce #content div.product span.price, .woocommerce #content div.product p.price, .woocommerce-page div.product span.price, .woocommerce-page div.product p.price, .woocommerce-page #content div.product span.price, .woocommerce-page #content div.product p.price, .woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price{
            color:#f8b80d;
        }
        a:hover{
            color:#f8b80d;
        }
        .events-listing .event-detail h4 a:hover, .featured-sermon h4 a:hover, .featured-gallery p, .post-more:hover, .widget_recent_comments a:hover{
            opacity:.9
        }
        p.drop-caps.secondary:first-child:first-letter, .accent-bg, .fa.accent-color, .btn-primary,
        .btn-primary.disabled,
        .btn-primary[disabled],
        fieldset[disabled] .btn-primary,
        .btn-primary.disabled:hover,
        .btn-primary[disabled]:hover,
        fieldset[disabled] .btn-primary:hover,
        .btn-primary.disabled:focus,
        .btn-primary[disabled]:focus,
        fieldset[disabled] .btn-primary:focus,
        .btn-primary.disabled:active,
        .btn-primary[disabled]:active,
        fieldset[disabled] .btn-primary:active,
        .btn-primary.disabled.active,
        .btn-primary[disabled].active,
        fieldset[disabled] .btn-primary.active,
        .dropdown-menu > .active > a,
        .dropdown-menu > .active > a:hover,
        .dropdown-menu > .active > a:focus,
        .nav-pills > li.active > a,
        .nav-pills > li.active > a:hover,
        .nav-pills > li.active > a:focus,
        .pagination > .active > a,
        .pagination > .active > span,
        .pagination > .active > a:hover,
        .pagination > .active > span:hover,
        .pagination > .active > a:focus,
        .pagination > .active > span:focus,
        .label-primary,
        .progress-bar,
        a.list-group-item.active,
        a.list-group-item.active:hover,
        a.list-group-item.active:focus,.panel-primary > .panel-heading, .carousel-indicators .active, .owl-theme .owl-controls .owl-page.active span, .owl-theme .owl-controls.clickable .owl-page:hover span, hr.sm, .flex-control-nav a:hover, .flex-control-nav a.flex-active, .title-note, .timer-col #days, .featured-block strong, .featured-gallery, .nav-backed-header, .next-prev-nav a, .event-description .panel-heading, .media-box .media-box-wrapper, .staff-item .social-icons a, .accordion-heading .accordion-toggle.active, .accordion-heading:hover .accordion-toggle, .accordion-heading:hover .accordion-toggle.inactive, .nav-tabs li a:hover, .nav-tabs li a:active, .nav-tabs li.active a, .fc-event, .site-header .social-icons a, .fc-event-inner, .timeline > li > .timeline-badge, .header-style3 .toprow{
            background-color: #f8b80d;
        }
        .mejs-controls .mejs-time-rail .mejs-time-loaded, p.demo_store, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce #respond input#submit.alt, .woocommerce #content input.button.alt, .woocommerce-page a.button.alt, .woocommerce-page button.button.alt, .woocommerce-page input.button.alt, .woocommerce-page #respond input#submit.alt, .woocommerce-page #content input.button.alt, .woocommerce .woocommerce-info:before, .woocommerce-page .woocommerce-info:before, .woocommerce .woocommerce-message:before, .woocommerce-page .woocommerce-message:before, .woocommerce span.onsale, .woocommerce-page span.onsale, .wpcf7-form .wpcf7-submit, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce .widget_layered_nav ul li.chosen a, .woocommerce-page .widget_layered_nav ul li.chosen a{
            background: #f8b80d;
        }
        .btn-primary:hover,
        .btn-primary:focus,
        .btn-primary:active,
        .btn-primary.active,
        .open .dropdown-toggle.btn-primary, .next-prev-nav a:hover, .staff-item .social-icons a:hover, .site-header .social-icons a:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce #content input.button.alt:hover, .woocommerce-page a.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce-page #content input.button.alt:hover, .woocommerce a.button.alt:active, .woocommerce button.button.alt:active, .woocommerce input.button.alt:active, .woocommerce #respond input#submit.alt:active, .woocommerce #content input.button.alt:active, .woocommerce-page a.button.alt:active, .woocommerce-page button.button.alt:active, .woocommerce-page input.button.alt:active, .woocommerce-page #respond input#submit.alt:active, .woocommerce-page #content input.button.alt:active, .wpcf7-form .wpcf7-submit{
            background: #f8b80d;
            opacity:.9
        }
        .woocommerce .woocommerce-info, .woocommerce-page .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-message{
            border-top-color: #f8b80d;
        }
        .nav .open > a,
        .nav .open > a:hover,
        .nav .open > a:focus,
        .pagination > .active > a,
        .pagination > .active > span,
        .pagination > .active > a:hover,
        .pagination > .active > span:hover,
        .pagination > .active > a:focus,
        .pagination > .active > span:focus,
        a.thumbnail:hover,
        a.thumbnail:focus,
        a.thumbnail.active,
        a.list-group-item.active,
        a.list-group-item.active:hover,
        a.list-group-item.active:focus,
        .panel-primary,
        .panel-primary > .panel-heading, .fc-event{
            border-color:#f8b80d;
        }
        .panel-primary > .panel-heading + .panel-collapse .panel-body{
            border-top-color:#f8b80d;
        }
        .panel-primary > .panel-footer + .panel-collapse .panel-body{
            border-bottom-color:#f8b80d;
        }
        blockquote{
            border-left-color:#f8b80d;
        }.site-header .topbar{
             height:81px;
         }
        .site-header h1.logo{
            height:66px;
        }
        .home .hero-slider{
            top:-82px;
            margin-bottom:-82px;
        }
        .home .slider-revolution-new{
            top:-82px;
            margin-bottom:-82px;
        } h1,h2,h3,h4,h5,h6,body,.event-item .event-detail h4,.site-footer-bottom{
              font-family:Roboto;
          }h4,.title-note,.btn,.top-navigation,.navigation,.notice-bar-title strong,.timer-col #days, .timer-col #hours, .timer-col #minutes, .timer-col #seconds,.event-date,.event-date .date,.featured-sermon .date,.page-header h1,.timeline > li > .timeline-badge span,.woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit, .woocommerce #content input.button, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .woocommerce-page #respond input#submit, .woocommerce-page #content input.button{
               font-family:Roboto Condensed;
           }blockquote p,.cursive,.meta-data,.fact{
                font-family:Volkhov;
            }
        /*========== User Custom CSS Styles ==========*/
        #header{
            margin: 0 auto;
        }                </style>

</head>

<body>
<!-- Navigation -->

<?php echo $__env->make('front.template.partials.nav_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Page Content -->
<div class="container">


    <?php echo $__env->yieldContent('content'); ?>
    <!-- Marketing Icons Section -->






    <hr>

    <!-- Call to Action Section -->




    <!-- Footer -->
    <footer >
        <div class="row pull-right">
            <div class="col-lg-12 ">
                <p>Todos los derechos reservados 2017 &copy; Compañerismo Estudiantil, Puebla.</p>
            </div>
        </div>
    </footer>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src="<?php echo e(asset('plugins/theme/js/jquery.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('plugins/theme/js/bootstrap.min.js')); ?>"></script>

<!-- Script to Activate the Carousel -->
<script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
</script>
<?php echo $__env->yieldContent('js'); ?>
</body>

</html>
