<?php $__env->startSection('title', 'Talleres'); ?>

<?php $__env->startSection('content'); ?>
 
 <h2 class="title-front left"><?php echo e(trans('app.title_last_article')); ?></h2>
 <div class="row">
            <div class="col-lg-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('front.index')); ?>">Home</a>
                    </li>
                    <li class="active">Talleres</li>
                </ol>
            </div>
        </div>
    <div class="row">
    <!-- Page Heading/Breadcrumbs -->
       
        <div class="col-md-8">
            <div class="row">
                <?php foreach($articles as $article): ?>
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <a href="<?php echo e(route('front.view.article', $article->slug)); ?>" class="thumbnail">
                                <?php foreach($article->images as $image): ?>
                                <img class="img-responsive img-article" src="<?php echo e(asset('upload/articles/' . $image->name)); ?>" alt="...">
                                <?php endforeach; ?>
                            </a>
                            <a href="<?php echo e(route('front.view.article', $article->slug)); ?>">
                                <h4 class="text-center"><?php echo e($article->title); ?></h4>
                            </a>
                            <hr>
                            <i class="fa fa-folder-open-o"><a href="<?php echo e(route('front.search.category', $article->category->name)); ?>"> <?php echo e($article->category->name); ?></a></i>
                            <div class="pull-right">
                                <i class="fa fa-clock-o"></i> <?php echo e($article->created_at->diffForHumans()); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
           <div class="text-center">
               <?php echo $articles->render(); ?>

           </div>
        </div>
    </div>

 <!-- /.row -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('/plugins/theme/js/jquery.gmap3.min.js')); ?>"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script>
        jQuery(function($){
            $('#map_canvas').gmap3({
                marker:{
                    address: '19.3598357,-98.1524267'

                },
                map:{
                    options:{
                        zoom: 15,
                        scrollwheel: true,
                        streetViewControl : true
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.main_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>