<nav>
    <div class="nav-wrapper #ffc400 amber accent-3">
        <a href="#!" class="brand-logo">
            <img src="<?php echo e(asset('/img/logo-compa.png')); ?>" alt="Logo">
        </a>
        <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
            <li class="active"><a href="<?php echo e(route('front.index')); ?>">INICIO</a></li>
            <li><a href="<?php echo e(route('front.registry')); ?>">EVENTOS</a></li>
            <li><a href="#">Javascript</a></li>
            <li><a href="#">Mobile</a></li>
        </ul>
        <ul class="side-nav" id="mobile-demo">
            <li><a href="#">Sass</a></li>
            <li><a href="#">Components</a></li>
            <li><a href="#">Javascript</a></li>
            <li><a href="#">Mobile</a></li>
        </ul>
    </div>
</nav>