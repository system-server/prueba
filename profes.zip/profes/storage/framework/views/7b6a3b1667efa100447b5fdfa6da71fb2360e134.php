<?php $__env->startSection('title', 'Error 404'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <h1 class="text-danger">La página no se ha encontrado.</h1>
        <div class="col-md-4"></div>
        <div class="col-md-4">

        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>