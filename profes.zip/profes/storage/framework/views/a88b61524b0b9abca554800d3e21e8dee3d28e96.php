<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Dashboard</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <!-- top tiles -->
    
    <div class="row tile_count">

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">

                <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
                <div class="count"> <?php echo e(App\User::all()->count()); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Contacts</span>
                <div class="count"> <?php echo e(App\Registry::all()->count()); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/1"><span class="count_top"></i>Sexualidad</span></a>
                <div class="count green"><?php echo e($taller1); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <a href="panel/list/2"><span class="count_top"></i>Una fe viva</span></a>
                <div class="count"><?php echo e($taller2); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/3"><span class="count_top"></i>Conociendo la historia</span></a>
                <div class="count"><?php echo e($taller3); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/4"><span class="count_top"></i>Cosmovision cristiana</span></a>
                <div class="count"><?php echo e($taller4); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/5"> <span class="count_top"></i>Método manuscrito</span></a>    
                <div class="count green"><?php echo e($taller5); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
            <a href="panel/list/6"><span class="count_top"></i>Evangelismo creativo</span></a>
               <div class="count green"><?php echo e($taller6); ?></div>
            </div>
         </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
                <div class="right">
                <a href="panel/list/7"> <span class="count_top"></i>Disciplinas espirituales</span></a>    
                <div class="count green"><?php echo e($taller7); ?></div>
            </div>
       </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
             <div class="left"></div>
             <div class="right">
             <a href="panel/list/8"> <span class="count_top"></i>Quién es Jesús</span></a>
               <div class="count green"><?php echo e($taller8); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
             <div class="left"></div>
             <div class="right">
             <a href="panel/list/9"> <span class="count_top"></i>Fe y profesión</span></a>    
                  <div class="count green"><?php echo e($taller9); ?></div>
            </div>
        </div>
        
  </div>
    <!-- /top tiles -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>