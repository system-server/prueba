<?php $__env->startSection('title', 'Home'); ?>

        <!-- Header Carousel -->

<?php echo $__env->make('front.template.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <br>

    <div class="notice-bar">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-6 notice-bar-title"> <span class="notice-bar-title-icon hidden-xs"><i class="fa fa-calendar fa-3x"></i></span> <span class="title-note">Siguiente</span> <strong>EVENTO PROXIMO</strong> </div>
                <div class="col-md-3 col-sm-6 col-xs-6 notice-bar-event-title">
                    <h5><a href="<?php echo e(route('front.registry_two')); ?>">Campamento de profesionistas</a></h5>
                    <span class="meta-data">septiembre 15, 2016</span> </div>

            </div>
        </div>
    </div>
    <!-- /.row -->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type ="text/javascript">                    jQuery(document).ready(function(){

        });                </script><script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/prettyphoto/js/prettyphoto.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/helper-plugins.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/bootstrap.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/waypoints.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/mediaelement/mediaelement-and-player.min.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/init.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/flexslider/js/jquery.flexslider.js?ver=4.3.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var upcoming_data = {"c_time":"1457389760"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/countdown/js/jquery.countdown.min.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/fullcalendar/jquery-ui.custom.min.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/fullcalendar/fullcalendar.min.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/plugins/fullcalendar/gcal.js?ver=4.3.3'></script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/sticky.js?ver=4.3.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var calenderEvents = {"homeurl":"http:\/\/compa.org.mx\/wp-content\/themes\/NativeChurch","monthNames":[],"monthNamesShort":[],"dayNames":[],"dayNamesShort":[],"googlefeeds":""};
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/calender_events.js?ver=4.3.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var urlajax = {"ajaxurl":"http:\/\/compa.org.mx\/wp-admin\/admin-ajax.php"};
        /* ]]> */
    </script>
    <script type='text/javascript' src='http://compa.org.mx/wp-content/themes/NativeChurch/js/event_ajax.js?ver=4.3.3'></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.main_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>