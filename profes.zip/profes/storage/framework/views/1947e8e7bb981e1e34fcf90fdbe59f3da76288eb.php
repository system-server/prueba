<?php $__env->startSection('title', 'Contactos'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Lista de contactos</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_title">
                    <h4><i class="glyphicon glyphicon-user"></i> Contactos registrados <?php echo e(\App\Registry::all()->count()); ?></h4>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(route('panel')); ?>">Exportar Excel</a>
                                </li>
                                <li><a href="#">Exportar PDF</a>
                                </li>
                            </ul>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <!-- start project list -->
                    <table class="table table-striped projects table-bordered table-hover">
                        <thead>
                        <tr>
                            <th style="width: 1%">ID</th>
                            <th style="width: 20%">Nombre</th>
                            <th>Email</th>
                            <th>Genero</th>
                            <th>Fecha de registro</th>
                            <th class="text-center">Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($contacts as $contact): ?>
                            <tr>
                                <td><?php echo e($contact->id); ?></td>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e($contact->email); ?></td>
                                <td> <?php echo e($contact->sexual_gender); ?></td>
                                <td> <?php echo e($contact->created_at); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('panel.contacts.show', $contact->id)); ?>" class="btn btn-primary btn-xs" data-toggle="tooltip" title="Perfil"><i class="fa fa-folder"></i></a>
                                    <?php if(Auth::user()->admin()): ?>
                                    <a href="<?php echo e(route('panel.contacts.destroy', $contact->id)); ?>"  onclick="return confirm('¿Seguro que deseas eliminarlo?')" class="btn btn-danger btn-xs" data-toggle="tooltip" title="Eliminar"><i class="fa fa-trash-o"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <!-- end project list -->

                    <div class="text-center">
                        <?php echo $contacts->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>