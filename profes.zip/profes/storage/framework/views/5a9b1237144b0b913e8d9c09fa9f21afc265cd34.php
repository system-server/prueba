<?php $__env->startSection('title', 'Registrado'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <h1 class="center-align">Gracias por registrarte</h1>
        <h5 class="center-align">En breve nos comunicaremos contigo</h5>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>
    <div class="row">
        <div class="input-field col s2"></div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>