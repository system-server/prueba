<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="title_left">
            <h3>Dashboard</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <!-- top tiles -->
    <div class="row tile_count">
        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
                <div class="count"> <?php echo e(App\User::all()->count()); ?></div>
            </div>
        </div>
        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Contacts</span>
                <div class="count"> <?php echo e(App\Registry::all()->count()); ?></div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Solteros</span>

                <div class="count green">  <?php echo e($single); ?> </div>
            </div>
        </div>

        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Casados</span>
                <div class="count"><?php echo e($married); ?></div>
            </div>
        </div>
        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Hombres</span>
                <div class="count"><?php echo e($man); ?></div>
            </div>
        </div>
        <div class="animated flipInY col-md-2 col-sm-4 col-xs-4 tile_stats_count">
            <div class="left"></div>
            <div class="right">
                <span class="count_top"><i class="fa fa-user"></i> Total Mujeres</span>
                <div class="count"><?php echo e($woman); ?></div>
            </div>
        </div>


    </div>
    <!-- /top tiles -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>