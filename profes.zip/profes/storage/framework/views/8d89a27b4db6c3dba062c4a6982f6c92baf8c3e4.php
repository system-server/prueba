<?php $__env->startSection('title', 'Contacto'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Contacto
                    <small>Campamento</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('front.index')); ?>">Home</a>
                    </li>
                    <li class="active">Registro</li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <!-- Contact Form -->
        <!-- In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
        <hr>
        <div class="row">
            <div class="col-md-4">
                <p>
                    Andrea Pineda
                </p>
                <p><i class="fa fa-phone"></i>
                    <abbr title="Phone">Telefono</abbr>: (222) 198-0171</p>
                <p><i class="fa fa-envelope-o"></i>
                    <abbr title="Email">Email</abbr>: <a href="mailto:name@example.com">compa.profes@gmail.com</a>
                </p>
                <ul class="list-unstyled list-inline list-social-icons">
                    <li>
                        <a href="https://www.facebook.com/events/498584150337152/" target="_blank"><i class="fa fa-facebook-square fa-2x" ></i></a>
                    </li>
                </ul>
                <p>Av. del Trabajo S/N,Santa Cruz </p>
                <p>Tlaxcala,90640 Tlaxcala de Xicohténcatl, Tlax.</p>
            </div>
            <div class="col-md-8">

                <div class="googlemap-wrapper">
                    <div id="map_canvas" class="map-canvas"></div>
                </div> <!-- /.googlemap-wrapper -->
            </div>
        </div>

    <!-- /.row -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('/plugins/theme/js/jquery.gmap3.min.js')); ?>"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script>
        jQuery(function($){
            $('#map_canvas').gmap3({
                marker:{
                    address: '19.3598357,-98.1524267'

                },
                map:{
                    options:{
                        zoom: 15,
                        scrollwheel: true,
                        streetViewControl : true
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.template.main_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>