<?php $__env->startSection('title', 'Registro'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <!-- Page Heading/Breadcrumbs -->
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Registro
                <small>Campamento</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('front.index')); ?>">Home</a>
                </li>
                <li class="active">Registro</li>
            </ol>
        </div>
    </div>
    <!-- /.row -->
    <!-- Contact Form -->
    <!-- In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

           <div class="row">
               <div class="col-md-8">
                   <?php echo Form::open(['route' => 'contact.store', 'method' => 'POST', 'class' => 'contactForm' ]); ?>


                   <div class="row">
                       <div class="col-md-12">
                      
                           <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="name">Nombre completo:</label>
                                   <input type="text" class="form-control" name="name" id="name" placeholder="Jose Diaz">
                                   <p class="help-block"></p>
                               </div>
                           </div>
                       </div>
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="email">Correo:</label>
                                   <input type="email" class="form-control" id="email" name="email" placeholder="example@gmail.com">
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="age">Edad:</label>
                                   <input type="number" class="form-control" name="age" id="age" placeholder="25">
                               </div>
                           </div>
                       </div>
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="phone">Telefono:</label>
                                   <input type="tel" class="form-control" id="phone" name="phone" placeholder="2221232425">
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="taller">Taller:</label>
                                   <?php echo Form::select('taller', ['1' => 'Casado', '2' => 'Soltero', '3'=>'3', '4' => '4', '5' => '5', '6' => '6', '7' =>'7', '8' => '8', '9' => '9'],
                                    null, ['class' => 'form-control','placeholder' => 'Seleccione una opción... ']); ?>

                               </div>
                           </div>
                       </div>
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="sexual_gender">Genero:</label>
                                   <?php echo Form::select('sexual_gender', ['Hombre' => 'Hombre', 'Mujer' => 'Mujer'],
                                    null, ['class' => 'form-control', 'placeholder' => 'Seleccione una opción... ']); ?>

                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="profession">Que estudias:</label>
                                   <input type="text" class="form-control" name="profession" id="profession" placeholder="Ingeniería">
                               </div>
                           </div>
                       </div>
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="you_reside">Donde radicas:</label>
                                   <input type="text" class="form-control" id="you_reside" name="you_reside" placeholder="Puebla">
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-6">
                           <div class="control-group form-group">
                               <div class="controls">
                                   <label for="participation">Participación en el estudio bíblico:</label>
                                   <?php echo Form::select('participation', ['lider' => 'Lider', 'asistente' => 'Asistente', 'no_asiste' => 'No asisto'],
                                    null, ['class' => 'form-control','placeholder' => 'Seleccione una opción... ']); ?>

                               </div>
                           </div>
                       </div>
                       <div class="col-md-6">

                       </div>
                   </div>


                   <div class="row">
                       <div class="col-md-6"></div>
                       <div class="col-md-6">
                           <div id="success"></div>
                           <!-- For success/fail messages -->
                           <button type="submit" class="btn btn-info pull-right">Registrar</button>
                           <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                       </div>


                   </div>
                   <?php echo Form::close(); ?>

               </div>
               <div class="col-md-4">
                   <h3>Contacto</h3>
                   <p>
                       Andrea Pineda
                   </p>
                   <p><i class="fa fa-phone"></i>
                       <abbr title="Phone">Telefono</abbr>: (222) 198-0171</p>
                   <p><i class="fa fa-envelope-o"></i>
                       <abbr title="Email">Email</abbr>: <a href="mailto:name@example.com">compa.profes@gmail.com</a>
                   </p>
                   <ul class="list-unstyled list-inline list-social-icons">
                       <li>
                           <a href="https://www.facebook.com/events/498584150337152/" target="_blank"><i class="fa fa-facebook-square fa-2x" ></i></a>
                       </li>
                   </ul>
                   <?php echo $__env->make('front.template.partials.alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                   <div class="googlemap-wrapper">
                       <div id="map_canvas" class="map-canvas"></div>
                   </div> <!-- /.googlemap-wrapper -->
               </div>
           </div>
</div>
<!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
        <!-- Contact Form JavaScript -->
<!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
<script src="<?php echo e(asset('plugins/theme/js/jqBootstrapValidation.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/theme/js/contact_me.js')); ?>"></script>

<script src="<?php echo e(asset('/plugins/theme/js/jquery.gmap3.min.js')); ?>"></script>
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script>
    jQuery(function($){
        $('#map_canvas').gmap3({
            marker:{
                address: '19.3598357,-98.1524267'

            },
            map:{
                options:{
                    zoom: 15,
                    scrollwheel: true,
                    streetViewControl : true
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.template.main_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>