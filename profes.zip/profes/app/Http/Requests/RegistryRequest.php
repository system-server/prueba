<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class RegistryRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|max:250|min:4',
            'email' => 'required|unique:records',
            'sexual_gender' => 'required|max:250|min:4',
            'taller' =>'required',
            'you_spend' => 'required|max:150|min:4',
            'you_reside' => 'required|max:150|min:4',
            'bible_study' => 'required',
            'participation' => 'required'
        ];
    }
}
