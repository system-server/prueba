<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Registry;
use Laracasts\Flash\Flash;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;


class ContactsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $contacts = Registry::orderBy('id', 'ASC')->paginate(5);
        return view('panel.contacts.index')->with('contacts', $contacts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function mostrar()
    {
       $lista = DB::table('records')->where('taller', '=', 'Sexualidad')->get();
      
       dd($lista);
        
//        return view('panel.contacts.list')->with('lista', $lista);
         return view('panel.contacts.lista', compact('lista'));


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $contact = new Registry($request->all());
        $taller1 = DB::table('records')->where('taller', '=', 'Sexualidad')->count();
        $taller2 = DB::table('records')->where('taller', '=', 'Una-fe-viva')->count();
        $taller3 = DB::table('records')->where('taller', '=', 'Conociendo-la-historia-de-la-Biblia')->count();
        $taller4 = DB::table('records')->where('taller', '=', 'Cosmovision-cristiana')->count();
        $taller5 = DB::table('records')->where('taller', '=', 'Método-manuscrito-de-E.B.')->count();
        $taller6 = DB::table('records')->where('taller', '=', 'Evangelismo-creativo')->count();
        $taller7 = DB::table('records')->where('taller', '=', 'Disciplinas-espirituales')->count();
        $taller8 = DB::table('records')->where('taller', '=', 'Quién-es-Jesús-y-que-significa-seguirlo')->count();
        $taller9 = DB::table('records')->where('taller', '=', 'Fe-y-profesión')->count();

        if ($taller1 < 10 and $taller2 < 10 and $taller3 < 10 and $taller4 < 10 and $taller5 < 10 and $taller6 < 10 and $taller7 < 10 and $taller8 < 10 and $taller9 < 10)
        {

            $contact->save();

            Flash::success("Se ha registrado el contacto  " . $contact->name . " de forma exitosa!");

            return redirect()->route('front.registry_two');
        } else{

            Flash::error("Cupo lleno para este taller de ".  $contact->taller);
            return redirect()->route('front.registry_two');
        }



    }


    public function excel()
    {
        Excel::create('Lista de Registros', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->get();

                $sheet->fromArray($products);

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $contact = Registry::find($id);
        return view('panel.contacts.show')->with('contact', $contact);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $contact = Registry::find($id);
        $contact->delete();
        Flash::error('El contacto ' . $contact->name . ' ha sido borrado de forma exitosa.');
        return redirect()->route('panel.contacts.index');
    }

    public function excel_2($id)
    {
       

         switch ($id) {
    case 1:
       
        Excel::create('Lista de Registros - Sexualidad', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Sexualidad')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');


        break;
    case 2:
       
        Excel::create('Lista de Registros - uns fe viva', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Una-fe-viva')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 3:
        Excel::create('Lista de Registros - Conociendo-la-historia-de-la-Biblia', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Conociendo-la-historia-de-la-Biblia')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 4:
      
        Excel::create('Lista de Registros - Cosmovision-cristiana', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Cosmovision-cristiana')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 5:

        Excel::create('Lista de Registros - Método-manuscrito-de-E.B.', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Método-manuscrito-de-E.B.')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 6:
      
        Excel::create('Lista de Registros - Evangelismo-creativo', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Evangelismo-creativo')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;

     case 7:
    
        Excel::create('Lista de Registros - Disciplinas-espirituales', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Disciplinas-espirituales')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
        

    case 8:
      
        Excel::create('Lista de Registros - Quién-es-Jesús-y-que-significa-seguirlo', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Quién-es-Jesús-y-que-significa-seguirlo')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 9:
      
        Excel::create('Lista de Registros - Fe-y-profesión', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Fe-y-profesión')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;             
        }

    }
    
}
