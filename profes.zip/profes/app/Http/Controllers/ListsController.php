<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Registry;
use Laracasts\Flash\Flash;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;


class ListsController extends Controller
{
    
    public function mostrar($id)
    {
        
        
        switch ($id) {
    case 1:
       $lists = DB::table('records')->where('taller', '=', 'Sexualidad')->get();
       $count = DB::table('records')->where('taller', '=', 'Sexualidad')->count();
        break;
    case 2:
       $lists = DB::table('records')->where('taller', '=', 'Una-fe-viva')->get();
       $count = DB::table('records')->where('taller', '=', 'Una-fe-viva')->count();
        break;
    case 3:
       $lists = DB::table('records')->where('taller', '=', 'Conociendo-la-historia-de-la-Biblia')->get();
       $count = DB::table('records')->where('taller', '=', 'Conociendo-la-historia-de-la-Biblia')->count();
        break;
    case 4:
       $lists = DB::table('records')->where('taller', '=', 'Cosmovision-cristiana')->get();
       $count = DB::table('records')->where('taller', '=', 'Cosmovision-cristiana')->count();
        break;
    case 5:
       $lists = DB::table('records')->where('taller', '=', 'Método-manuscrito-de-E.B.')->get();
       $count = DB::table('records')->where('taller', '=', 'Método-manuscrito-de-E.B.')->count();
        break;
    case 6:
       $lists = DB::table('records')->where('taller', '=', 'Evangelismo-creativo')->get();
       $count = DB::table('records')->where('taller', '=', 'Evangelismo-creativo')->count();
        break;

     case 7:
        $lists = DB::table('records')->where('taller', '=', 'Disciplinas-espirituales')->get();
       $count = DB::table('records')->where('taller', '=', 'Disciplinas-espirituales')->count();
        break;
        

    case 8:
        $lists = DB::table('records')->where('taller', '=', 'Quién-es-Jesús-y-que-significa-seguirlo')->get();
       $count = DB::table('records')->where('taller', '=', 'Quién-es-Jesús-y-que-significa-seguirlo')->count();
        break;
    case 9:
       
        $lists = DB::table('records')->where('taller', '=', 'Fe-y-profesión')->get();
       $count = DB::table('records')->where('taller', '=', 'Fe-y-profesión')->count();
        break;             
        }
       
      
    
       return view('panel.contacts.lista', compact('lists', 'count', 'id'));


    }

    public function excel($id)
    {
       

         switch ($id) {
    case 1:
       
        Excel::create('Lista de Registros - Sexualidad', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Sexualidad')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');


        break;
    case 2:
       
        Excel::create('Lista de Registros - uns fe viva', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Una-fe-viva')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 3:
        Excel::create('Lista de Registros - Conociendo-la-historia-de-la-Biblia', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Conociendo-la-historia-de-la-Biblia')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 4:
      
        Excel::create('Lista de Registros - Cosmovision-cristiana', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Cosmovision-cristiana')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 5:

        Excel::create('Lista de Registros - Método-manuscrito-de-E.B.', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Método-manuscrito-de-E.B.')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 6:
      
        Excel::create('Lista de Registros - Evangelismo-creativo', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Evangelismo-creativo')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;

     case 7:
    
        Excel::create('Lista de Registros - Disciplinas-espirituales', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Disciplinas-espirituales')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
        

    case 8:
      
        Excel::create('Lista de Registros - Quién-es-Jesús-y-que-significa-seguirlo', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Quién-es-Jesús-y-que-significa-seguirlo')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;
    case 9:
      
        Excel::create('Lista de Registros - Fe-y-profesión', function($excel) {

            $excel->sheet('Contactos', function($sheet) {

                $products = Registry::select('id','name', 'age', 'email', 'study',  'sexual_gender',
                    'you_reside', 'participation', 'phone', 'taller')->where('taller', '=', 'Fe-y-profesión')->get();

                $sheet->fromArray($products);
              

            });
        })->export('xls');
    //    return redirect()->route('panel.contacts.index');
        break;             
        }
    }

   
}
