<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Category;
use App\Article;
use App\Image;
use Laracasts\Flash\Flash;
use App\Http\Requests\ArticleRequest;


class ArticlesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $articles = Article::orderBy('id', 'ASC')->paginate(5);
        $articles->each(function ($articles){
            $articles->category;
            $articles->user;
        });
        return view('panel.articles.index')->with('articles', $articles);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::orderBy('name', 'ASC')->lists('name', 'id');

        return view('panel.articles.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ArticleRequest $request)
    {
        if($request->file('image'))
        {
            $file = $request->file('image');
            $name = 'article_' . time() . '.' . $file->getClientOriginalExtension();
            $path = public_path() . '/upload/articles';
            $file->move($path, $name);
        }

        $data = $request->all();
        $data['active'] = isset($data['active']) ? 1 : 0;
        $article = new Article($data);
        $article->user_id = \Auth::user()->id;
        $article->save();



        $image = new Image();
        $image->name = $name;
        // $image->article_id * $article->id;
        $image->article()->associate($article);
        $image->save();



        $message = $data['active'] == 1 ? ' Será publicado inmediatamente en el sitio.' : ' queda a la espera de ser activado en el sitio.';


        Flash::success("Se ha registrado el articulo  " . $article->title ." correctamente en el sistema y "  .  $message);

        return redirect()->route('panel.articles.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {


        $article = Article::find($id);
        $categories = Category::orderBy('name', 'ASC')->lists('name', 'id');
        return view('panel.articles.edit', compact('categories', 'article'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    //     
       

        $data = $request->all();
        $data['active'] = isset($data['active']) ? 1 : 0;
        $article = Article::find($id);
        \Storage::delete($article->path);
        $article->fill($data);

        $article->save();



        Flash::warning('Sea actualizado el articulo ' . $article->title . ' de forma exitosa!');

        return redirect()->route('panel.articles.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $article = Article::find($id);
        if($id->file('image'))
        {

        }

        $article->delete();

        Flash::error('Se ha borrado el articulo ' . $article->title . ' de forma exitosa!');

        return redirect()->route('panel.articles.index');
    }
}
