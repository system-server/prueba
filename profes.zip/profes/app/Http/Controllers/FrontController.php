<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Article;
use App\Http\Controllers\Controller;
use App\Category;
use Carbon\Carbon;


class FrontController extends Controller
{
 public function __construct()
    {
        Carbon::setLocale('es');
    }

   

    public function index()
    {
        return view('front.index');

    }

    public function registry()
    {
        return view('front.registry_two');
    }

    public function message ()
    {
        return view('front.message');
    }

    public function contact ()
    {
        return view('front.contact');
    }

     public function searchCategory($name)
    {
        $category = Category::SearchCategory($name)->first();
        $articles = $category->articles()->paginate(4);
        $articles->each(function($articles){
            $articles->category;
            $articles->images;
        });
        return view('front.list')->with('articles', $articles);
    }

     public function viewArticle($slug)
    {
        $article = Article::findBySlugOrFail($slug);
        $article->category;
        $article->user;
        $article->images;

        return view('front.article')->with('article', $article);
    }


    public function workshop()
    {
        $articles = Article::orderBy('id', 'ASC')->paginate(9);
        $articles->each(function($articles){
            $articles->category;
            $articles->images;
        });
       return view('front.list')->with('articles', $articles);
    }
    

}
