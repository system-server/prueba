<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Registry;
use App\User;
use Illuminate\Support\Facades\DB;



class PanelController extends Controller
{
    public  function index ()
    {
        $contacts = Registry::orderBy('id', 'ASC');
        $users = User::orderBy('id', 'ASC');
        
//**************************Lista de Talleres****************************************************\\   
        $taller1 = DB::table('records')->where('taller', '=', 'Sexualidad')->count();
        $taller2 = DB::table('records')->where('taller', '=', 'Una-fe-viva')->count();
        $taller3 = DB::table('records')->where('taller', '=', 'Conociendo-la-historia-de-la-Biblia')->count();
        $taller4 = DB::table('records')->where('taller', '=', 'Cosmovision-cristiana')->count();
        $taller5 = DB::table('records')->where('taller', '=', 'Método-manuscrito-de-E.B.')->count();
        $taller6 = DB::table('records')->where('taller', '=', 'Evangelismo-creativo')->count();
        $taller7 = DB::table('records')->where('taller', '=', 'Disciplinas-espirituales')->count();
        $taller8 = DB::table('records')->where('taller', '=', 'Quién-es-Jesús-y-que-significa-seguirlo')->count();
        $taller9 = DB::table('records')->where('taller', '=', 'Fe-y-profesión')->count();

        return view('panel.index', compact('contacts', 'users','taller1','taller2','taller3','taller4','taller5','taller6','taller7','taller8','taller9'));

    }


}
