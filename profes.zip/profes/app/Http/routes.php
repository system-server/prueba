<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/**
 * Route Front
 */

Route::get('/', [
    'uses' => 'FrontController@index',
    'as' => 'front.index'
    ]);

Route::get('registro', [
    'uses' => 'FrontController@registry',
    'as' => 'front.registry_two'
]);

Route::get('registrado', [
    'uses' => 'FrontController@message',
    'as' => 'front.message'
]);

Route::get('contacto', [
    'uses' => 'FrontController@contact',
    'as' => 'front.contact'
]);

Route::get('categories/{name}', [
    'uses' => 'FrontController@searchCategory',
    'as' => 'front.search.category'
]);

Route::get('talleres', [
    'uses' => 'FrontController@workshop',
    'as' => 'front.list'
    ]);

Route::get('talleres/{slug}', [
    'uses' => 'FrontController@viewArticle',
    'as' => 'front.view.article'
]);



Route::group(['prefix' => 'panel', 'middleware' => 'auth'], function (){
    /**
     * Welcome Panel Admin
     */
/*
    Route::get('/',['as' => 'panel.index', function () {
        return view('panel.index');
    }]);*/

    Route::get('/',[
        'uses' => 'PanelController@index',
        'as' => 'panel.index'
    ]);


    Route::group(['middleware' => 'admin'], function(){

        Route::resource('users', 'UsersController');
        Route::get('users/{id}/destroy', [
            'uses' => 'UsersController@destroy',
            'as' => 'panel.users.destroy'
        ]);

 Route::resource('contacts', 'ContactsController');
        Route::get('contacts/{id}/destroy', [
            'uses' => 'ContactsController@destroy',
            'as' => 'panel.contacts.destroy'
        ]);

 Route::resource('categories', 'CategoriesController');
    Route::get('categories/{id}/destroy', [
        'uses' => 'CategoriesController@destroy',
        'as' => 'panel.categories.destroy'
    ]);

    Route::resource('articles', 'ArticlesController');
    Route::get('articles/{id}/destroy', [
        'uses' => 'ArticlesController@destroy',
        'as' => 'panel.articles.destroy'
    ]);
   
    

    
    });

Route::resource('contacts', 'ContactsController');

    Route::resource('categories', 'CategoriesController');

     Route::resource('articles', 'ArticlesController');


Route::get('excel',[
        'uses' => 'ContactsController@excel',
        'as' => 'panel.excel'
    ]);

    Route::get('list/excel2/{id}',[
        'uses' => 'ContactsController@excel_2',
        'as' => 'panel'
    ]);

  
    Route::get('list/{id}',[
        'uses' => 'ListsController@mostrar',
        'as' => 'panel.contacts.lista'
    ]);
 
    

   
});

/**
 * Route login
 */


Route::get('panel/auth/login', [
    'uses' => 'Auth\AuthController@getLogin',
    'as' => 'panel.auth.login'
]);
Route::post('panel/auth/login', [
    'uses' => 'Auth\AuthController@postLogin',
    'as' => 'panel.auth.login'
]);
Route::get('panel/auth/logout', [
    'uses' => 'Auth\AuthController@getLogout',
    'as' => 'panel.auth.logout'
]);
