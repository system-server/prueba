<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\SluggableInterface;
use Cviebrock\EloquentSluggable\SluggableTrait;
use App\Category;
use Illuminate\Support\Facades\DB;

class Article extends Model implements SluggableInterface
{
    use SluggableTrait;

    protected $sluggable = [
        'build_from' => 'title',
        'save_to'    => 'slug'
    ];

    protected $table = 'articles';

    protected $fillable = ['title', 'content', 'category_id','active', 'user_id', 'autor'];

    public function category ()
    {
        return $this->belongsTo('App\Category');
    }

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function images()
    {
        return $this->hasMany('App\Image');
    }

    public function tags()
    {
        return $this->belongsToMany('App\Tag');
    }

    /**
     * Function for show category name
     * @return mixed
     */
    public function get_nameCategory()
    {
        return $this->category->name;
    }

    /**
     * Function for show tags count
     * @return mixed
     */
    public function get_tags()
    {
        return $this->tags()->count();
    }

    /**
     * Function for show username
     * @return mixed
     */
    public function get_nameUser()
    {
        return $this->user->name;
    }

    /**
     * Scope search articles
     * @return array
     */

    public function scopeSearch($query, $title)
    {
        return $query->where('title', 'LIKE', "%$title%");
    }

    public function  nameTags()
    {
        return $this->tags->lists('id')->toArray();
    }
}
