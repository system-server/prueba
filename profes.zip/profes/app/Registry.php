<?php

namespace App;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Registry extends Model
{

    protected $table = 'records';

    protected $fillable = [
        'name', 'age', 'email', 'sexual_gender', 'you_reside', 'phone', 'taller', 'study', 'participation',
    ];


}
